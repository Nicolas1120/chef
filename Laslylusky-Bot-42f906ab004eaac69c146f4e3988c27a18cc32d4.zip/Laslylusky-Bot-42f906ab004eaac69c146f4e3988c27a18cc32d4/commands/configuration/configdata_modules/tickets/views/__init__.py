from .list_view import TicketsListView
from .detail_view import TicketDetailView
from .perms_view import TicketPermsView
from .messages_view import TicketMessagesView