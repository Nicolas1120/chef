from .embed import EmbedCommand

async def setup(bot):
    pass