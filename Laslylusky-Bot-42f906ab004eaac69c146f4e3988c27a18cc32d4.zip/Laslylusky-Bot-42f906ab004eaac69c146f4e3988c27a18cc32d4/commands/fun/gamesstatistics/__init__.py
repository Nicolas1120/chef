from .hangman_stats import get_hangman_stats_embed, get_hangman_stats_view
from .minesweeper_stats import get_minesweeper_stats_embed, get_minesweeper_stats_view
from .blackjack_stats import get_blackjack_stats_embed, get_blackjack_stats_view

async def setup(bot):
    pass